// ============================================================================
// SOLANA SWEEPER COMPONENT
// ============================================================================
// Standalone component for sweeping Solana tokens to USDC/SOL

'use client';

import React, { useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet,
  RefreshCw,
  CheckCircle,
  Loader2,
  AlertTriangle,
  Coins,
  ArrowRight,
  Search,
  Zap,
  X,
  XCircle,
  ExternalLink,
} from 'lucide-react';
import { useSolanaSweeper } from './useSolanaSweeper';
import type { SolanaTokenInfo, SolanaSwapResult } from './config';

// Helper functions
function formatNumber(num: number, decimals: number = 2): string {
  if (num === 0) return '0';
  if (num < 0.0001) return '< 0.0001';
  if (num < 1) return num.toFixed(Math.min(decimals + 2, 6));
  if (num < 1000) return num.toFixed(decimals);
  if (num < 1000000) return `${(num / 1000).toFixed(1)}K`;
  return `${(num / 1000000).toFixed(2)}M`;
}

function formatUSD(value: number): string {
  if (value < 0.01) return '< $0.01';
  return `$${formatNumber(value)}`;
}

function shortenAddress(address: string): string {
  return `${address.slice(0, 4)}...${address.slice(-4)}`;
}

export default function SolanaSweeperPage() {
  const { connected, publicKey } = useWallet();
  
  const {
    tokens,
    selectedTokens,
    isScanning,
    isProcessing,
    progressStep,
    error,
    swapResults,
    outputToken,
    totalSelectedValue,
    selectedCount,
    scanWallet,
    toggleToken,
    selectAll,
    selectNone,
    setOutputToken,
    executeSwap,
    clearError,
    clearResults,
  } = useSolanaSweeper();
  
  // Auto-scan when wallet connects
  useEffect(() => {
    if (connected && publicKey && tokens.length === 0 && !isScanning) {
      // Small delay to let connection settle
      const timer = setTimeout(() => {
        scanWallet();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [connected, publicKey, tokens.length, isScanning, scanWallet]);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-purple-950">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-slate-800/50 backdrop-blur-xl bg-slate-900/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Solana Sweeper</h1>
                <p className="text-xs text-slate-400">Batch swap to USDC or SOL</p>
              </div>
            </div>
            
            <WalletMultiButton />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Sweep Your Solana Tokens
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto">
            Convert multiple SPL tokens to USDC or SOL using Jupiter aggregator.
            Batched transactions for efficiency.
          </p>
        </motion.div>

        {/* Results Modal */}
        <AnimatePresence>
          {swapResults && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-800 border border-slate-700 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl"
              >
                <div className="p-6 border-b border-slate-700">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-white">Sweep Results</h3>
                    <button onClick={clearResults} className="p-2 hover:bg-slate-700 rounded-lg">
                      <X className="w-5 h-5 text-slate-400" />
                    </button>
                  </div>
                </div>
                
                <div className="p-4 max-h-[400px] overflow-y-auto">
                  <div className="space-y-2">
                    {swapResults.map((result, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border ${
                          result.status === 'success'
                            ? 'bg-emerald-500/10 border-emerald-500/30'
                            : result.status === 'failed'
                            ? 'bg-red-500/10 border-red-500/30'
                            : 'bg-yellow-500/10 border-yellow-500/30'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {result.status === 'success' ? (
                            <CheckCircle className="w-4 h-4 text-emerald-400" />
                          ) : result.status === 'failed' ? (
                            <XCircle className="w-4 h-4 text-red-400" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-yellow-400" />
                          )}
                          <span className="font-medium text-white">{result.symbol}</span>
                          <span className="text-xs text-slate-500">{shortenAddress(result.mint)}</span>
                        </div>
                        {result.signature && (
                          <a
                            href={`https://solscan.io/tx/${result.signature}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-2 flex items-center gap-1 text-xs text-purple-400 hover:text-purple-300"
                          >
                            <ExternalLink className="w-3 h-3" />
                            View on Solscan
                          </a>
                        )}
                        {result.error && (
                          <p className="mt-1 text-xs text-red-400">{result.error}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="p-4 border-t border-slate-700">
                  <button
                    onClick={clearResults}
                    className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-xl"
                  >
                    Done
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Main Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl overflow-hidden"
        >
          {/* Not Connected */}
          {!connected && (
            <div className="p-12 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-700/50 flex items-center justify-center">
                <Wallet className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Connect Your Wallet</h3>
              <p className="text-slate-400 mb-6">Connect your Solana wallet to scan for tokens</p>
              <WalletMultiButton />
            </div>
          )}

          {/* Connected */}
          {connected && (
            <>
              {/* Controls */}
              <div className="p-4 border-b border-slate-700/50 bg-slate-900/30">
                <div className="flex flex-wrap items-center gap-4">
                  <button
                    onClick={() => scanWallet(false)}
                    disabled={isScanning || isProcessing}
                    className="flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-xl font-medium transition"
                  >
                    {isScanning ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : tokens.length > 0 ? (
                      <RefreshCw className="w-4 h-4" />
                    ) : (
                      <Search className="w-4 h-4" />
                    )}
                    {isScanning ? 'Scanning...' : tokens.length > 0 ? 'Refresh' : 'Scan Wallet'}
                  </button>

                  {/* Output Token Selector */}
                  <div className="flex items-center gap-2 bg-slate-900/50 rounded-xl p-1">
                    <button
                      onClick={() => setOutputToken('USDC')}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                        outputToken === 'USDC'
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      → USDC
                    </button>
                    <button
                      onClick={() => setOutputToken('SOL')}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                        outputToken === 'SOL'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      → SOL
                    </button>
                  </div>

                  {/* Network Badge */}
                  <div className="ml-auto flex items-center gap-2 px-3 py-1.5 bg-slate-900/50 rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-purple-400" />
                    <span className="text-sm text-slate-300">Solana</span>
                  </div>
                </div>
              </div>

              {/* Token List */}
              <div className="p-4">
                {tokens.length === 0 && !isScanning && (
                  <div className="py-12 text-center">
                    <Coins className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                    <p className="text-slate-400">Click "Scan Wallet" to find tokens</p>
                  </div>
                )}

                {isScanning && (
                  <div className="py-12 text-center">
                    <Loader2 className="w-10 h-10 text-purple-400 mx-auto mb-4 animate-spin" />
                    <p className="text-slate-300">{progressStep || 'Scanning...'}</p>
                  </div>
                )}

                {tokens.length > 0 && (
                  <>
                    {/* Select All/None */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-slate-400">
                        {selectedCount} of {tokens.length} tokens selected
                      </span>
                      <div className="flex gap-2">
                        <button onClick={selectAll} className="text-xs text-purple-400 hover:text-purple-300">
                          Select All
                        </button>
                        <span className="text-slate-600">|</span>
                        <button onClick={selectNone} className="text-xs text-slate-400 hover:text-slate-300">
                          Clear
                        </button>
                      </div>
                    </div>

                    {/* Tokens */}
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                      {tokens.map((token) => {
                        const isSelected = selectedTokens.has(token.mint);
                        
                        return (
                          <motion.div
                            key={token.mint}
                            layout
                            className={`p-3 rounded-xl border transition ${
                              isSelected
                                ? 'bg-slate-800 border-purple-500/50'
                                : 'bg-slate-800/30 border-transparent opacity-60'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              {/* Checkbox */}
                              <button
                                onClick={() => toggleToken(token.mint)}
                                className={`w-5 h-5 rounded flex items-center justify-center border transition ${
                                  isSelected
                                    ? 'bg-purple-500 border-purple-500'
                                    : 'border-slate-600 hover:border-slate-500'
                                }`}
                              >
                                {isSelected && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                              </button>

                              {/* Logo */}
                              {token.logoUrl ? (
                                <img
                                  src={token.logoUrl}
                                  alt={token.symbol}
                                  className="w-8 h-8 rounded-full"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).style.display = 'none';
                                  }}
                                />
                              ) : (
                                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                                  <span className="text-xs text-slate-400">
                                    {token.symbol.slice(0, 2)}
                                  </span>
                                </div>
                              )}

                              {/* Info */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium text-white">{token.symbol}</span>
                                  <span className="text-xs text-slate-500">{shortenAddress(token.mint)}</span>
                                </div>
                                <div className="text-sm text-slate-400">
                                  {token.balanceFormatted}
                                </div>
                              </div>

                              {/* Value */}
                              <div className="text-right">
                                <div className="text-purple-400 font-medium">
                                  {formatUSD(token.valueUsd)}
                                </div>
                                <div className="text-xs text-slate-500">
                                  @ ${formatNumber(token.price, 4)}
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>

              {/* Action Footer */}
              {tokens.length > 0 && (
                <div className="p-4 border-t border-slate-700/50 bg-slate-900/30">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-sm text-slate-400">Total Value:</span>
                      <span className="ml-2 text-xl font-bold text-white">
                        {formatUSD(totalSelectedValue)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-400">
                      {selectedCount} token{selectedCount !== 1 ? 's' : ''} → {outputToken}
                    </div>
                  </div>

                  <button
                    onClick={executeSwap}
                    disabled={isProcessing || selectedCount === 0}
                    className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-semibold text-lg transition flex items-center justify-center gap-2"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        {progressStep || 'Processing...'}
                      </>
                    ) : (
                      <>
                        <ArrowRight className="w-5 h-5" />
                        Sweep {selectedCount} Token{selectedCount !== 1 ? 's' : ''} to {outputToken}
                      </>
                    )}
                  </button>
                </div>
              )}
            </>
          )}
        </motion.div>

        {/* Error Display */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-xl"
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                <p className="text-red-200">{error}</p>
                <button onClick={clearError} className="ml-auto text-red-400 hover:text-red-300">
                  ✕
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <div className="p-4 bg-slate-800/30 backdrop-blur border border-slate-700/50 rounded-xl">
            <Coins className="w-6 h-6 text-purple-400 mb-2" />
            <h3 className="font-medium text-white mb-1">Batch Swaps</h3>
            <p className="text-sm text-slate-400">
              Bundle multiple swaps per transaction using Jupiter
            </p>
          </div>
          <div className="p-4 bg-slate-800/30 backdrop-blur border border-slate-700/50 rounded-xl">
            <Zap className="w-6 h-6 text-blue-400 mb-2" />
            <h3 className="font-medium text-white mb-1">Best Rates</h3>
            <p className="text-sm text-slate-400">
              Jupiter aggregator finds optimal swap routes
            </p>
          </div>
          <div className="p-4 bg-slate-800/30 backdrop-blur border border-slate-700/50 rounded-xl">
            <RefreshCw className="w-6 h-6 text-pink-400 mb-2" />
            <h3 className="font-medium text-white mb-1">Auto Discovery</h3>
            <p className="text-sm text-slate-400">
              Helius API finds all your SPL tokens
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
